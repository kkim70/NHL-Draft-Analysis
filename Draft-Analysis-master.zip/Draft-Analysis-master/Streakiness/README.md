Streakiness code + data.
