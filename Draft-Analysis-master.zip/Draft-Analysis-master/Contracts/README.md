Fun with contracts.
