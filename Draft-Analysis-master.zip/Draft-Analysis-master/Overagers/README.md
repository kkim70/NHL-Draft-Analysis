overagers.pdf are my slides. (Slightly messy) code and data files are in the Code folder.

If you want to scrape the data yourself, feel free to use get_data.R to do that. 

If not, all the analysis files should work with the data I have uploaded (current as of 10/12/2018).
