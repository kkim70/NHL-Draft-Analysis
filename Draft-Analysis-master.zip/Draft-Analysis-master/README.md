Calculate teams' best possible draft outcomes and compare them to actual draft outcomes.

Check NHL Draft folder for most recent code. Feel free to change the value metric from Point Shares to Games Played, GVT, whatever.
