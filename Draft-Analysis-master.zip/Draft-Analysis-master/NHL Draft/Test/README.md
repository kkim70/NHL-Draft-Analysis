Testing draft models.
